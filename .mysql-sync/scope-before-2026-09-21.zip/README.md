# VietinCare AI

## Theo dõi tiến độ

Xem [checklist công việc](PROJECT_CHECKLIST.md) để biết phần đã làm, phần còn thiếu và thứ tự ưu tiên. Quy tắc đọc, tự cập nhật checklist và nhắc tiến độ sau mỗi đợt sửa được lưu trong [AGENTS.md](AGENTS.md).

## Cơ sở dữ liệu

Project thống nhất dùng **MySQL Community Server 8.0.46** cho dữ liệu nghiệp vụ và dữ liệu phục vụ RAG. Tất cả bảng dùng InnoDB, bộ ký tự `utf8mb4` và collation `utf8mb4_0900_ai_ci`.

- Script khởi tạo: `SQLQuery1.sql`.
- Tên database: `QLKHViettin`.
- Có 15 bảng: 14 bảng nghiệp vụ và `KnowledgeChunk` lưu các đoạn tri thức.
- Khóa tự tăng dùng `INT AUTO_INCREMENT`; văn bản dùng `VARCHAR` hoặc `LONGTEXT`; thời gian dùng `DATETIME(3)`.
- Mỗi kết nối backend phải đặt `SET NAMES utf8mb4` và `SET SESSION time_zone = '+00:00'`. Thời gian lưu theo UTC; giao diện chuyển sang giờ Việt Nam.
- Giữ nguyên cách viết tên bảng trong script khi truy vấn, đặc biệt khi triển khai trên Linux.

## Khởi tạo

Mở `SQLQuery1.sql` bằng MySQL Workbench, kết nối máy chủ MySQL và chạy toàn bộ script trên môi trường mới. Tài khoản thực thi cần quyền tạo database và bảng.

Hoặc mở MySQL CLI từ thư mục project:

```text
mysql --default-character-set=utf8mb4 -u root -p
```

Sau khi nhập mật khẩu:

```sql
SOURCE SQLQuery1.sql;
```

Script không xóa bảng hay dữ liệu. `CREATE DATABASE IF NOT EXISTS` chỉ xử lý việc database đã tồn tại; các lệnh tạo bảng vẫn yêu cầu bảng chưa tồn tại. Khi cập nhật database đã có dữ liệu, cần một migration riêng, không chạy lại script khởi tạo để thay đổi cấu trúc.

## Thiết kế RAG dùng MySQL

`KnowledgeBase` lưu tài liệu. `KnowledgeChunk` lưu nội dung từng đoạn, thứ tự, embedding dạng JSON, tên mô hình, số chiều và thời gian tạo. Backend tạo embedding, kiểm tra các phần tử là số, chọn các đoạn từ tài liệu đã xuất bản, rồi tính cosine similarity và lấy các đoạn phù hợp để tạo phản hồi. Chỉ so sánh embedding cùng mô hình và cùng số chiều; vector có độ dài bằng 0 phải được xử lý trước khi tính cosine.

Thiết kế này dành cho quy mô đồ án với tập tài liệu nhỏ. MySQL lưu dữ liệu; phép tìm kiếm tương đồng được thực hiện ở backend, không giả định MySQL 8.0 có chỉ mục vector tích hợp. Luồng backend và AI hiện chưa được triển khai trong frontend của project.

## Tài liệu

- `03_ban2.docx`: yêu cầu, lưu trữ MySQL và luồng RAG.
- `04_ban1.docx`: mô hình lớp, quan hệ dữ liệu và thiết kế lưu trữ MySQL.
- `05_GenAI_SoftwareDevelopment_functional-testing.docx`: môi trường kiểm thử MySQL 8.0.46. Các kết quả nghiệp vụ cũ phải được chạy lại trên phiên bản mới trước khi nghiệm thu.

Tài liệu cú pháp chính thức: [CREATE TABLE](https://dev.mysql.com/doc/refman/8.0/en/create-table.html), [JSON](https://dev.mysql.com/doc/refman/8.0/en/json.html).
