# Checklist tiến độ VietinCare AI

Cập nhật gần nhất: 2026-09-21 (Asia/Saigon).

Đây là nơi theo dõi công việc chung của project. Mỗi lần sửa mã nguồn, SQL hoặc tài liệu, trợ lý đọc và cập nhật file này theo `AGENTS.md`, rồi nhắc người dùng việc tiếp theo trong câu trả lời cuối.

## Trạng thái hiện tại

- Có frontend VI/EN cho trang chủ, đăng nhập và đăng ký; xác thực và chatbot vẫn là demo.
- Có script MySQL 8.0.46 tạo 15 bảng, gồm `KnowledgeChunk`; chưa có backend trong thư mục project.
- Ba tài liệu Word đã cập nhật nội dung hệ quản trị sang MySQL; chưa kiểm tra trực quan bố cục sau chỉnh sửa.
- Các kết quả kiểm tra trước đây bên dưới được ghi lại từ phiên làm việc ngày 2026-09-20, không phải vừa chạy lại khi tạo checklist.
- Các trang trong `VI/README.txt` là cấu trúc đề xuất; không coi chúng là các chức năng đã được xây dựng.

## Cách ghi tiến độ

- `[x]`: đã đạt tiêu chí của mục; `[ ]`: chưa hoàn thành. Ghi thêm **Đang làm**, **Chưa kiểm chứng** hoặc **Bị chặn** trong nội dung nếu cần.
- P0: sửa nền tảng trước; P1: luồng demo nghiệp vụ cốt lõi; P2: mở rộng và hoàn thiện nghiệm thu.
- Khi bắt đầu một mục, ghi ID vào phần “Việc tiếp theo”. Sau khi sửa, cập nhật mục và thêm nhật ký kèm kiểm tra thực tế.
- Giữ ID ổn định. Không dùng tỷ lệ hoàn thành suy đoán hoặc kết quả Pass cũ để đại diện cho phiên bản mới.

## Việc tiếp theo

**DB-07 đang bị chặn ở xác thực:** người dùng đã khởi động MySQL80, đã kiểm tra trạng thái Running. Kết nối root không mật khẩu bị từ chối (1045); cần cấu hình đăng nhập cục bộ trước khi kiểm tra database hiện có và nhập schema. Không gửi hoặc lưu mật khẩu trong hội thoại/project. Thứ tự đề xuất sau khi xử lý kết nối:

1. **DB-02, DB-03**: thống nhất liên kết tài khoản khách hàng và ràng buộc sở hữu dữ liệu.
2. **BE-01, AUTH-01**: chọn stack backend, kết nối MySQL, triển khai xác thực và phân quyền.
3. **TK-01 đến TK-03**: hoàn thành luồng khách hàng tạo ticket → nhân viên xử lý → khách hàng xem kết quả.

## Những việc đã hoàn thành

- [x] **FE-01 · P0** Sửa phạm vi biến trong chat, gửi trùng từ ô preview và dùng `textContent` cho tin nhắn. File: `script.js`. Kiểm tra trước đây: chat có phản hồi, gửi một lần, bỏ qua tin trống và hiển thị đầu vào dưới dạng văn bản.
- [x] **FE-02 · P0** Khôi phục form đăng ký tiếng Việt; sửa đường dẫn CSS/JS, chuyển ngôn ngữ và điều hướng VI/EN. File: `VI/`, `EN/`, `script.js`. Kiểm tra trước đây: tổng cộng 72 kiểm tra bằng Node cho liên kết, ID, form và hành vi JavaScript; chưa thay thế kiểm thử trình duyệt.
- [x] **FE-03 · P0** Nêu rõ trạng thái demo trong thông báo đăng nhập/đăng ký; thêm Enter ở ô chat preview; tách CSS trang chủ VI vào `landing-vi.css`.
- [x] **DB-01 · P0** Chuyển `SQLQuery1.sql` sang MySQL 8.0.46, InnoDB, utf8mb4, `AUTO_INCREMENT`, `DATETIME(3)` và `LONGTEXT`; bổ sung `KnowledgeChunk` cho RAG. Đã tạo thành công 15 bảng trên MySQL tạm; kiểm tra tiếng Việt/emoji, JSON, liên kết ticket và engine/collation đạt. Script kiểm tra: `.mysql-sync/smoke.sql`. Database tạm đã được dọn dẹp.
- [x] **DOC-01 · P0** Cập nhật nội dung MySQL/RAG trong `03_ban2.docx`, `04_ban1.docx`, `05_GenAI_SoftwareDevelopment_functional-testing.docx`; thêm hướng dẫn trong `README.md`. Kiểm tra XML đạt, không còn tên hệ quản trị cũ trong phần văn bản được quét. Báo cáo ghi rõ cần chạy lại kiểm thử nghiệp vụ trên MySQL. Kiểm tra bố cục vẫn thuộc DOC-02.
- [x] **TRACK-01 · P0** Tạo checklist, quy tắc tự cập nhật trong `AGENTS.md` và liên kết từ README. Hoàn thành khi file có trạng thái thực tế, công việc tiếp theo và nhật ký.

## Nền tảng dữ liệu và backend

- [ ] **DB-07 · P0 · Bị chặn** Tạo database project trên MySQL đã cài trên máy. MySQL80 đã Running sau khi người dùng khởi động; kết nối root không mật khẩu bị từ chối (1045). Chờ cấu hình login-path `vietincare` bằng `mysql_config_editor` trên máy người dùng. Chưa tạo hoặc sửa database trên dịch vụ này. Đạt khi kết nối được, kiểm tra schema hiện có, khởi tạo an toàn và xác nhận đủ bảng. Không lưu mật khẩu vào checklist.
- [ ] **DB-02 · P0** Liên kết `Customer` với `UserAccount`; chốt tài khoản khách hàng và chat khách vãng lai. Đạt khi từ tài khoản đăng nhập xác định được đúng khách hàng, không trùng thông tin định danh ngoài chủ đích.
- [ ] **DB-03 · P0** Ràng buộc quyền sở hữu ticket/phiên chat/đánh giá; quy định mục tiêu của mỗi đánh giá. Đạt khi dữ liệu khác khách hàng bị từ chối và có kiểm thử trường hợp sai.
- [ ] **DB-04 · P0** Chuẩn hóa `NULL/NOT NULL`, trạng thái, mức ưu tiên, thang tin cậy AI, cảm xúc, điểm NPS và thứ tự ngày giờ. Đạt khi SQL, tài liệu và dữ liệu kiểm thử cùng quy tắc.
- [ ] **DB-05 · P1** Bổ sung định danh người gửi, phản hồi ticket độc lập với phiên chat, lịch sử trạng thái và mốc chuyển giao. Đạt khi truy vết được ai xử lý/gửi tin và khi nào.
- [ ] **DB-06 · P1** Tạo migration, dữ liệu mẫu không nhạy cảm và index theo truy vấn thực tế. Đạt khi nâng cấp được database có dữ liệu mà không xóa dữ liệu cũ.
- [ ] **BE-01 · P0** Chọn stack backend, tạo cấu trúc API và cấu hình MySQL qua biến môi trường. Đạt khi chạy được backend, kết nối MySQL và có hướng dẫn khởi động; không đưa bí mật vào mã nguồn.
- [ ] **AUTH-01 · P1 · UC001/UC012** Đăng ký, đăng nhập, đăng xuất, băm mật khẩu, phiên và phân quyền Customer/Agent/Supervisor/Admin. Đạt khi API từ chối sai mật khẩu, sai quyền và truy cập dữ liệu người khác.
- [ ] **AUTH-02 · P2 · UC001** OTP, quên mật khẩu, giới hạn thử đăng nhập và hết hạn phiên theo đặc tả đã thống nhất. Đạt khi kiểm tra cả hết hạn, mã sai và gửi lại.

## Khách hàng và nhân viên hỗ trợ

- [ ] **TK-01 · P1 · UC003** Tạo ticket, trả mã theo dõi, lưu MySQL và hiển thị lỗi nhập liệu. Trang đề xuất: `support-create.html`.
- [ ] **TK-02 · P1 · UC007** Lịch sử và chi tiết ticket theo đúng khách hàng; trạng thái và phản hồi còn sau khi tải lại trang. Trang đề xuất: `support-history.html`, `support-detail.html`.
- [ ] **TK-03 · P1 · UC007** Nhân viên nhận ticket, phản hồi, cập nhật trạng thái và đóng ticket; khách hàng xem được phản hồi. Trang đề xuất: `support-agent.html`.
- [ ] **CHAT-01 · P1 · UC002** Lưu phiên chat và tin nhắn vào MySQL, tải lại lịch sử; xử lý chờ phản hồi, lỗi mạng và gửi lại không trùng.
- [ ] **HAND-01 · P1 · UC006** Chuyển AI sang nhân viên kèm lịch sử, hàng chờ, tiếp nhận và trường hợp không có nhân viên trực.
- [ ] **EVAL-01 · P2 · UC010** Đánh giá sau khi hoàn thành hỗ trợ; chốt cách thu CSAT/NPS, kiểm tra quyền và quy tắc gửi nhiều lần.

## AI và cơ sở tri thức

- [ ] **AI-01 · P1 · UC002/UC011** Nhập tài liệu/FAQ, chia đoạn, tạo embedding và lưu MySQL; backend truy xuất chỉ tài liệu được xuất bản. Đạt khi câu trả lời có nguồn, có xử lý thiếu nguồn/lỗi AI và không lộ khóa API.
- [ ] **AI-02 · P1 · UC004/UC005** Phân loại ticket, mức ưu tiên và cảm xúc; định nghĩa cách tính ngưỡng tin cậy. Đạt khi có bộ câu hỏi gán nhãn để đánh giá, gồm tình huống phàn nàn bị phân loại sai trước đây.
- [ ] **AI-03 · P2 · UC008** AI Copilot gợi ý phản hồi cho Agent; nhân viên được sửa và chủ động gửi, có ghi nhận gợi ý được chọn.
- [ ] **AI-04 · P2 · UC009** Tóm tắt khi chuyển giao/kết thúc hội thoại, lưu kèm nguồn hội thoại và hiển thị cho nhân viên.

## Quản trị và giao diện

- [ ] **ADMIN-01 · P2 · UC012** Quản lý tài khoản, nhân viên và vai trò; kiểm tra quyền ở backend.
- [ ] **ADMIN-02 · P2 · UC011** Giao diện quản lý tri thức, phiên bản và xuất bản; kiểm tra định dạng/kích thước file tải lên.
- [ ] **ADMIN-03 · P2 · UC013** Dashboard Supervisor dùng dữ liệu thực: ticket, thời gian xử lý, chuyển giao, hiệu quả AI và đánh giá; định nghĩa cách tính trước khi hiển thị.
- [ ] **ADMIN-04 · P2 · UC014/UC015** Audit log và cấu hình hệ thống; thống nhất lại tên UC015 vốn không khớp phần mô tả cấu hình.
- [ ] **FE-04 · P1** Kiểm tra thực tế trên trình duyệt desktop/mobile: chat, đăng ký, đăng nhập, menu, đổi kích thước và chuyển ngôn ngữ; ghi trình duyệt/kích thước và kết quả.
- [ ] **FE-05 · P2** Hoàn thiện các liên kết placeholder, FAQ/liên hệ, nhãn hỗ trợ truy cập và nội dung VI/EN. Chỉ công bố các khả năng/số liệu đã có hoặc đánh dấu demo rõ ràng.
- [ ] **FE-06 · P2** Rà soát CSS chung và CSS dashboard để tránh trùng `.logo`, `.nav`, `.hero`; xác nhận không làm thay đổi giao diện ngoài dự kiến.

## Tài liệu, kiểm thử và nghiệm thu

- [ ] **DOC-05 · P1** Đối chiếu danh mục tài liệu với file thực tế: ngày 2026-09-21 tìm thấy `02_ban2.docx`, `03_ban2.docx`, `04_ban1.docx`; chưa tìm thấy `05_GenAI_SoftwareDevelopment_functional-testing.docx` được README và lịch sử checklist tham chiếu. Bổ sung bản kiểm thử đúng phiên bản hoặc sửa danh mục sau khi xác minh; không coi kết quả kiểm thử cũ là bằng chứng hiện tại.
- [ ] **SCOPE-01 · P0** Chốt phạm vi nghiệm thu đồ án từ tài liệu 02/03: phân kỳ web chat, ticket, RAG và phân quyền so với Voicebot, Core Banking/CRM, sinh trắc học, Kubernetes/GPU, 5.000 phiên và uptime 99,9%. Tài liệu 02 ghi hạn 27/09/2026; cần xác nhận còn áp dụng. Đạt khi phạm vi, tiêu chí đo và phần mô phỏng được thống nhất trong tài liệu; hiện mới là đề xuất rà soát.
- [ ] **DOC-02 · P1 · Chưa kiểm chứng** Render và xem bố cục cả 3 Word sau chỉnh sửa; kiểm tra cả sơ đồ dạng ảnh. Trước đây chưa làm được vì thiếu bộ render; kiểm tra XML không xác nhận hình ảnh hoặc phân trang.
- [ ] **DOC-03 · P1** Đồng bộ đặc tả với thiết kế: thời điểm tạo ticket, trạng thái, bộ nhãn cảm xúc, đăng nhập khách hàng, Supervisor, UC015 và mục tiêu thời gian phản hồi.
- [ ] **DOC-04 · P2** Đồng bộ ERD/mô hình với SQL triển khai, gồm `KnowledgeChunk`; sửa các lỗi đánh số, thuộc tính lặp và ngày TC04 `16/2026` sau khi xác minh ngày đúng.
- [ ] **QA-01 · P1** Lập ma trận UC → API/trang → test case → bằng chứng; mở rộng 5 test case hiện có cho lỗi đầu vào, quyền, trạng thái và ngoại lệ.
- [ ] **QA-02 · P1** Chạy lại kiểm thử tích hợp MySQL/backend/frontend; chỉ ghi Pass khi có kết quả thực tế theo phiên bản. Smoke test tạo bảng không thay thế kiểm thử nghiệp vụ.
- [ ] **QA-03 · P1** Kiểm thử toàn luồng: khách hàng chat → tạo ticket → nhân viên nhận/phản hồi → hoàn thành → khách hàng đánh giá.
- [ ] **QA-04 · P2** Đo hiệu năng AI theo mục tiêu đã thống nhất; kiểm tra hết phiên, lỗi AI, tải lên, dữ liệu nhạy cảm và quyền truy cập. Không suy ra các cam kết bảo mật/uptime từ một lần demo.
- [ ] **RELEASE-01 · P2** Hoàn thiện hướng dẫn cài đặt/chạy, cấu hình mẫu, dữ liệu demo, backup/khôi phục và kịch bản trình bày; người khác có thể dựng môi trường theo README.

## Nhật ký thay đổi

Ngày 2026-09-21 · DOC-03, DOC-04, DOC-05, SCOPE-01: Rà soát nội dung văn bản/bảng OOXML của 3 DOCX hiện có, README, SQL, JavaScript và cấu trúc frontend VI/EN. Phát hiện danh mục thiếu file kiểm thử 05; tài liệu 02 có phạm vi triển khai rộng và mốc 27/09/2026. Xác nhận các điểm cần thống nhất: UC001 chỉ nêu người dùng nội bộ nhưng thiết kế 04 có đăng nhập khách hàng; 03 tạo ticket khi yêu cầu phức tạp còn 04 tạo trước AI; trạng thái Mới/Chờ xử lý; cảm xúc 3/4 nhãn; phản hồi dưới 2 giây so với dưới 5 giây; UC015 có tên tài khoản nhưng nội dung cấu hình. SQL chưa liên kết Customer–UserAccount, chưa có nơi lưu phản hồi ticket độc lập với chat, tệp đính kèm UC003 hoặc cấu hình UC015. Chỉ cập nhật phát hiện/checklist, không sửa mã nguồn, SQL hoặc Word, không đánh dấu chức năng hoàn thành. Chưa render/xem sơ đồ ảnh Word, chưa chạy trình duyệt, backend hoặc MySQL trong phiên này; trạng thái DB-07 vẫn theo lịch sử, chưa xác minh lại.

Ngày 2026-09-20 · DB-07: Log người dùng cung cấp cho thấy lần chạy đặt lại mật khẩu bằng init-file thất bại do không tìm thấy `C:\mysql-init.txt` (OS errno 2); MySQL đã Shutdown complete. Chưa xác nhận đổi mật khẩu hoặc đăng nhập thành công. Tiếp theo: kiểm tra tên/vị trí file tạm ngoài project, chạy lại rồi kiểm tra đăng nhập. Không đọc hoặc lưu nội dung file chứa mật khẩu vào project.

| Ngày | Công việc | Thay đổi và kiểm tra | Phần còn lại |
|---|---|---|---|
| 2026-09-20 | FE-01, FE-02, FE-03 | Sửa frontend VI/EN; kiểm tra cú pháp JS và 72 kiểm tra bằng Node đạt trong phiên trước. | Kiểm thử trình duyệt FE-04; backend chưa có. |
| 2026-09-20 | DB-01, DOC-01 | Chuyển MySQL, tạo 15 bảng, kiểm tra dữ liệu mẫu đạt; cập nhật nội dung 3 Word và README, kiểm tra XML đạt trong phiên trước. | DOC-02 và chạy lại các test nghiệp vụ. |
| 2026-09-20 | TRACK-01 | Tạo `PROJECT_CHECKLIST.md`, `AGENTS.md`, liên kết README; đối chiếu danh sách file và README/SQL hiện tại để ghi trạng thái. | Bắt đầu DB-02, DB-03 khi người dùng yêu cầu triển khai tiếp. |
| 2026-09-20 | DB-07 | Kiểm tra dịch vụ MySQL80 đang dừng; thử khởi động trong và ngoài sandbox đều bị từ chối quyền. Chưa kết nối được database thực. | Khởi động MySQL80 bằng quyền Administrator, sau đó kiểm tra tài khoản kết nối và schema hiện có. |
| 2026-09-20 | DB-07 | Người dùng khởi động dịch vụ thành công; xác nhận Running. Thử kết nối root không mật khẩu trả lỗi 1045. | Cấu hình đăng nhập cục bộ rồi kiểm tra schema trước khi tạo bảng. |

## Lưu ý khi tiếp tục

- Không tự chạy lại `SQLQuery1.sql` trên database thật đã có bảng; `.mysql-sync/smoke.sql` chỉ dùng trong môi trường kiểm thử thích hợp.
- Bản sao Word trước chuyển MySQL từng được tạo tại `.mysql-sync/documents-before-mysql.zip`; kiểm tra file còn tồn tại trước khi cần khôi phục.
- Chưa chốt stack backend. Danh sách việc mở là kế hoạch; không phải các tính năng đã được triển khai.
- Trợ lý nhắc tiến độ trong phiên làm việc với project; không có tác vụ chạy nền theo dõi thay đổi bên ngoài phiên.
